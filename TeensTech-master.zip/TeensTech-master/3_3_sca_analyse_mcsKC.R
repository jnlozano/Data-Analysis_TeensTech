##########################################################################################
# Specification Curve Analysis and Digital Technology Use
# R-Script 3.3: MCS Analyse Specification Curves
# Version 1.3
##########################################################################################
#setwd(".../2_sca")
library(tidyverse)

getwd()
source("../0_1_1mcs_KC.R") #set the working directory BUT Mod and 0_1_1mcs must be present"

#################################################
# Bind Both
#################################################
load("2_3_sca_mcs_results_cm.rda")
load("2_3_sca_mcs_results_pr.rda")

results_mcs_sca_cm$respondent <-
  rep("Cohort Member", nrow(results_mcs_sca_cm))
results_mcs_sca_pr$respondent <-
  rep("Parent", nrow(results_mcs_sca_pr))

results_mcs_sca_total <- rbind(results_mcs_sca_cm, results_mcs_sca_pr)
save(results_mcs_sca_total, file = "2_3_sca_mcs_results.rda")

####################################################################################
# Number of specifications
####################################################################################
nrow(results_mcs_sca_total)

####################################################################################
# Median effects table 2
# total, separate x variables, controls/no controls (calls eta-squared "effect size" and stad slop "effect")
# %>% pipes in anad makes nesting run. makes code more transparent? it is in dyplr
####################################################################################
results_mcs_sca_total %>% summarise(median_effect = median(effect, na.rm = TRUE), median_effectsize = median(rsqrd, na.rm = TRUE)) # are the stats pulled from same row?

results_mcs_sca_total %>% filter(respondent == "Parent") %>% summarise(median_effect = median(effect, na.rm = TRUE), median_effectsize = median(rsqrd, na.rm = TRUE))
results_mcs_sca_total %>% filter(respondent == "Cohort Member") %>% summarise(median_effect = median(effect, na.rm = TRUE), median_effectsize = median(rsqrd, na.rm = TRUE))

results_mcs_sca_total %>% filter(controls == "Controls") %>% summarise(median_effect = median(effect, na.rm = TRUE), median_effectsize = median(rsqrd, na.rm = TRUE))
results_mcs_sca_total %>% filter(controls == "No Controls") %>% summarise(median_effect = median(effect, na.rm = TRUE), median_effectsize = median(rsqrd, na.rm = TRUE))

results_mcs_sca_total %>% filter(x_variable == "fctvho00r") %>% summarise(median_effect = median(effect, na.rm = TRUE), median_effectsize = median(rsqrd, na.rm = TRUE))
results_mcs_sca_total %>% filter(x_variable == "fccomh00r") %>% summarise(median_effect = median(effect, na.rm = TRUE), median_effectsize = median(rsqrd, na.rm = TRUE))
results_mcs_sca_total %>% filter(x_variable == "fccomh00r") %>% summarise(median_effect = median(effect, na.rm = TRUE), median_effectsize = median(rsqrd, na.rm = TRUE))
results_mcs_sca_total %>% filter(x_variable == "fcinth00r") %>% summarise(median_effect = median(effect, na.rm = TRUE), median_effectsize = median(rsqrd, na.rm = TRUE))
results_mcs_sca_total %>% filter(x_variable == "fcsome00r") %>% summarise(median_effect = median(effect, na.rm = TRUE), median_effectsize = median(rsqrd, na.rm = TRUE))

####################################################################################
### Table 2 Components (return to get the med for even number of obs)
####################################################################################
table2<-data.frame() #init table 2

selection.list<-c("Parent","Cohort Member","Controls", "No Controls","fctvho00r","fccomh00r","fccomh00r","fcinth00r","fcsome00r")
selection.target<-c("respondent", "respondent", "controls", "controls", "x_variable", "x_variable","x_variable","x_variable","x_variable")

### get subsets output
for (i in 1:length(selection.list)) {

  selection.arg<-paste(selection.target[i]," == ","'",selection.list[i],"'",sep="")
  selection.exp<-parse(text=paste("subset(results_mcs_sca_total, ", selection.arg,")",sep="")) #use parse/eval to deal with the string/quotes substitutions
  subsets <- eval(selection.exp)
  subsets<-subsets[is.na(subsets$effect)==FALSE,] #na.rm
  subsets<-subsets[order(subsets$effect),] #reorder output table so it is in order to get the P50.

  p50<-nrow(subsets) #fix p50 name here, as it is now p100

  if (p50 %% 2 == 0) { #deal with even numbers
    p50.u<-trunc(dim(subsets)[1]/2)+1 #number of rows divide by 2 (to get median)
    p50.l<-trunc(dim(subsets)[1]/2)

    subset_results.u<-as.data.frame(subsets[p50.u,]) #pull out the middle 2 models after sorting by effect est
    subset_results.l<-as.data.frame(subsets[p50.l,]) #pull out the middle 2 models after sorting by effect est
    subset_results.cc<-rbind(subset_results.u,subset_results.l)
    subset_results.u[1,c(4:9)] <-  apply(subset_results.cc[,c(4:9)],2,mean) #get the mean of the two middle models
    subset_results<- subset_results.u
    rm(subset_results.u)
    rm(subset_results.l)
    rm(subset_results.cc)

  } else {

    subset_results<-as.data.frame(subsets[trunc(p50/2)+1,]) #pull out the middle model after sorting by effect est. note p50 here is nrows

  }



  subset_results$model<-AnlsVers #index the model
  subset_results$sex<-SexLabel #index the sex

  if(i<5){
    subset_results$x_variable<-"Combined"
  }
  if(i==1 | i==2){
    subset_results$controls<-"Combined"
  }
  if(i==3 | i==4){
    subset_results$respondent<-"Combined"
  }
  if(i>4){
    subset_results$respondent<-"Combined"
    subset_results$controls<-"Combined"
  }

  table2<-rbind(table2,subset_results[1,]) #build up from the top
}

### get overall/combinded model stat, because was not easy to incorporate above control structure-loop  /// all assumes no NAs
subsets<- results_mcs_sca_total #start with the fresh full set of all the model outputs
subsets<-subsets[is.na(subsets$effect)==FALSE,] #na.rm
rows<-dim(subsets)[1]
p50<-dim(subsets)[1]/2 #number of rows divide by 2 (to get median) --what happened to even N median coding?

if (rows %% 2 == 0) { #deal with even numbers
  p50.u<-trunc(dim(subsets)[1]/2)+1 #number of rows divide by 2 (to get median)
  p50.l<-trunc(dim(subsets)[1]/2)
  subsets<-subsets[order(subsets$effect),] #reorder output table so it is in order to get the P50.
  subset_results.u<-as.data.frame(subsets[p50.u,]) #pull out the middle 2 models after sorting by effect est
  subset_results.l<-as.data.frame(subsets[p50.l,]) #pull out the middle 2 models after sorting by effect est
  subset_results.cc<-rbind(subset_results.u,subset_results.l)
  subset_results.u[1,c(4:9)] <-  apply(subset_results.cc[,c(4:9)],2,mean) #get the mean of the two middle models
  subset_results<- subset_results.u #apply to standard object name and finish processing pipeline
  rm(subset_results.u)
  rm(subset_results.l)
  rm(subset_results.cc)

} else {
  subsets<-subsets[order(subsets$effect),]
  subset_results<-as.data.frame(subsets[trunc(p50)+1,]) #pull out the middle model after sorting by effect est
 print("line131")
}

subset_results$x_variable<-"Combined"; subset_results$respondent<-"Combined";


  subset_results$controls<-"Combined" #add the two attributes NOT used for subseting in this instance


subset_results$model<-AnlsVers #index the model
subset_results$sex<-SexLabel #index the model

table2<-rbind(table2,subset_results[1,]);names(table2) #add the overall median to the
#table2<-table2[ c(dim(table2)[1],1:(dim(table2)[1]-1)), c(dim(table2)[2],dim(table2)[2]-1,3,1,4:(dim(table2)[2]-2))] #column 2 is not included as it has lists of IVs which we don't look at specifically because it is not this one model that is special
table2<-table2[ c(dim(table2)[1],1:(dim(table2)[1]-1)), !(names(table2) %in% c("y_variable"))] #column 2 is not included as it has lists of IVs which we don't look at specifically because it is not this one model that is special
table2<-table2[,c("model","sex","respondent","controls","x_variable","effect","rsqrd" ,"standard_error","t_value","p_value")] #reorder
names(table2)

table2$y_var_set<-paste(ItemsLabel, ScalesLabel,sep="")

######################################################
### Cleaning up some missing design features to index
######################################################
table2$PRemotionItems<-EmoItemOnlyLabel
table2$run<-RunNum
table2$CurveFit<-GAMMLabel
table2$CodeVersion<-code_version #pulls code version from 0_1.R
table2$IV<-IVtypeLabel
table2$ItemsLabel<-ItemsLabel
table2$ScalesLabel<-ScalesLabel
table2$cont<-ControlLabel
table2$SDQincluded<-SDQincludedLabel
table2<-table2[,c("model","sex","PRemotionItems","ItemsLabel","ScalesLabel","y_var_set","SDQincluded","IV","CurveFit","respondent","controls","cont", "x_variable","effect","rsqrd" ,"standard_error","t_value","p_value","CodeVersion")] #reorder

print("line 161")


#######################################################
### Export Table 2 Components
########################################################

eval(parse(text=paste("table2.",AnlsVers,"<-table2",sep=""))) #hold as object
write.csv(table2,file=paste("table2.",AnlsVers,".csv",sep="")) #write out the table
print(table2)

####################################################################################
### Confirming data is coming from the appropriate place for the particular model run
####################################################################################
print(paste("Running model for: ", AnlsVers," ",SexLabel,sep = ""))
print(paste("Using data from: ", getwd(),sep=""))
print("End 3_3_sca_analyse_mcs")
print(RunNum)

#######################################################
### Collect up for Compliation Table 2
#######################################################


if (GAMM == 0) {
table2.comp<-read.csv("../CompTable2_0.csv", header = TRUE)
table2.comp2<-rbind(table2.comp, table2) #append
write.csv(table2.comp2,"../CompTable2_0.csv",row.names = FALSE) #append to prior csv
}

if (GAMM == 2) {
table2.comp<-read.csv("../CompTable2_2.csv")
table2.comp2<-rbind(table2.comp, table2) #append
write.csv(table2.comp2,"../CompTable2_2.csv",row.names = FALSE) #append to prior csv
}

if (GAMM != 2 & GAMM != 0) {
table2.comp<-read.csv("../CompTable2.csv") #bring in the template or prior collection
table2.comp2<-rbind(table2.comp, table2) #append
write.csv(table2.comp2,"../CompTable2.csv",row.names = FALSE) #append to prior csv
}




# break
#
 #table2.comp2<-table2[1,];table2.comp2[1,]<-"NA" # make the collection file template
 #write.csv(table2.comp2[1,],"../CompTable2.csv",row.names = FALSE) #append to prior csv
 # write.csv(table2.comp2[1,],"../CompTable2_0.csv",row.names = FALSE) #append to prior csv
 #write.csv(table2.comp2[1,],"../CompTable2_2.csv",row.names = FALSE) #append to prior csv
#
#
#
#
#
