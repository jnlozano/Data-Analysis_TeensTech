'1_1_prep_yrbsJL.R'
Modified slightly due to change in current data. Data pulled from CDC: https://www.cdc.gov/healthyyouth/data/yrbs/data.htm (2/20/20)
Changed q28_n to be read properly. Original is commented out. Using this modified script utilizes current YRBS data pulled directly from the website. 
