##########################################################################################
# Specification Curve Analysis and Digital Technology Use
# R-Script 0.2: Run across all the evalautions structurs
#   THIS FILE IS SOURCED AT THE END OF THE 1_3
# File: 0_2_mcs_KC.R
# Author: KMC
# Notes:
# Ini Date: Aug 29, 2019
# Questions:
# History:
# Version: 1.2- Set up to step from DV/IV limits, then social media only, then sex-specific
# Version: 1.2.1 -Fix bug
# Version: 1.3- add piecewise with knot set at 2hrs
#           1.3.2 Fixed a bug in the DV selection
#         1.4 Added in option to limit the control variables
#         1.4.1 Add in self-harm DV
#         1.4.2 Add in Limited SDQ without head ache
#         1.5 Extend to different IV sets
##########################################################################################

### 1.0 Set up environment
#moved. deferred to each script

#!!!# comment out one of these
rootwd<-"~/Dionysus/Twenge/OrbenXS/TeensTech/" #this is on local machines
#rootwd<-"~XXXX" #this todd's space. this needs to be absolute not relative, cuz it will become recursive otherwise

### 2.0 Set up the global paramaters
code_version<-paste("v1.5_",Sys.Date(), sep="")

### 2.2 Run the Control Structure for tailoring of the code to each of the models

  # 2.2.1 set up the lables for the model type
if(GAMM==0){
  GAMMLabel<-"First Order OLS"
} else if (GAMM==1) {
  GAMMLabel<-"GAMM"
} else if (GAMM==2){
  GAMMLabel <-"Piecewise OLS: One ChangePoint Located Knot"
} else if (GAMM==3){
  GAMMLabel <-paste("Piecewise OLS: One Preset Location Knot at ",knot_location,sep="")
}

  # 2.2.2 set up the labels for the sex
if(Mod>1){ #only Mod one is not sex-specific
  SexLabel<-dplyr:: recode(Sex,'0'='Girls', '1'="Boys") #Create Lables
} else {
  SexLabel<-"Combined"
}

  # 2.2.3 set up the labels for marker of item inclusion
if(Items==0) {
  ItemsLabel<-"NoItems"
} else if (Items==1){
  ItemsLabel<-"Items"
}

  # 2.2.4 set up labels for indicator of scale adjustments
if(Scales==0) {
  ScalesLabel<-"NoNewScls"
} else if (Scales==1){
  ScalesLabel<-"Scales"
  if (NoSDQHeadAche==1){ # drop head ache indicator
    ScalesLabel<-paste(ScalesLabel,"Adj SDQ Emotion",sep="")
  }
  if (SelfHarm==1){ #add selfharm indicator
    ScalesLabel<-paste(ScalesLabel,"W_Slf-hrm",sep="")
  }
}

#########
if (dropSDQ==1) {
  SDQincludedLabel<-"SDQ_NOT_included"
} else {
  SDQincludedLabel<-"Includes_SDQ"
}


  # 2.2.5 set up labels for SDQ suite
if (EmoItemOnly==1) { # SDQ is limited to the emotion subscale
  EmoItemOnlyLabel<-"Limited_SDQ_to_Emotion"
} else {
  EmoItemOnlyLabel<-"All SDQ items"
}

###########################################
### 2.3 Modify the analysis for SCA Run ###
###########################################

### 2.3.0
if (Mod==1) {

  ### 2.3.0.1 Label constant features of this SCA configurtion
  AnlsVers<-"Orben_Model"
  print(Mod)
  SexLabel<-"Combined"

} else {

  if (Mod==2) {
    ###select the subset to be used
    AnlsVers<-"SexSpecific"
    print(Mod)

  } else {
    if (Mod==3) {
      ###select the subset to be used
      AnlsVers<-"SocMdOnly_SexSpec"
      SexLabel
      if (GAMM==3){
        AnlsVers<-paste("SocMdOnly_SexSpec_wBreak_at_",knot_location,sep="")
      }
      print(Mod)

    } else {

      if (Mod==4) {
        ###select the subset to be used
        AnlsVers<-"Scales_SocMedOnly_SxSpcfic"
        print(Mod)

      } else {

        if (Mod==5) {
          ###select the subset to be used
          AnlsVers<-"SocMedOnly"
          SexLabel<-"Combined";Sex<-"NA";Sexr<-"NA"
          print(Mod)
          Mod<-3 #send back to run as Mod 3 (which is with soc media only)
        } else {
          print("Mod is not set")
          break
        }
      }
    }
  }
}

#### Label the Limited IV set
if (IVtype == 0) { # limit to just social media
  IVtypeLabel <- "SocMedia"
}
if (IVtype == 1) { # limit to just social media
  IVtypeLabel <- "WeekdayTV"
}

if (IVtype == 2) { # limit to just social media
  IVtypeLabel <- "eGames"
}

if (IVtype == 4) { # limit to just social media
  IVtypeLabel <- "Internet"
}

###

  # 2.3.1 Set what adjustments will be made
if (LimitedControls==1){ #was the parameter set to limit the controls?
  ControlLabel<-"Demo's Controls" # mark the analysis as limited to the demographic controls
}
if (LimitedControls==0){ #was the parameter set to limit the controls?
  ControlLabel<-"Orben Controls" # mark the analysis as using the original controls of Orben
  }
if (LimitedControls==2){ #was the parameter set to limit the controls?
  ControlLabel<-"Twenge Controls" # mark the analysis as using the original controls of Orben
}
  # 2.3.2 Subset the Data by Sex if Sex-specifc analysis
Sexr<-as.numeric(dplyr:: recode(Sex,'0'='2','1'='1')) #recode so Sex input matches the MCS data. THe recodes the input paramter (to not break orben code down stream)
if (SexLabel!="Combined"){ #if it is sex specific models then use the sex to pull the data
  ##if(override_sex_test!=1){ #test sex: skip sex specfic in testing DROP THIS IF IT PASSES
  data<-data[data$fccsex00==Sexr,] # codebook mcs6_cm_assessment_ukda_data_dictionary.rtf indicates 1 is male, 2 is femaile BUT how does this run here?
  ##}#test sex: skip sex specfic in testing DROP THIS IF IT PASSES
} else {
  print("combined sex analysis");Sys.sleep(2)
}

print(table(data$fccsex00));print(SexLabel) # data must be in memory but will be scrubbed???

### 2.4 set up the Mod specific environment
twd<-(paste(rootwd,"OrbenExt",AnlsVers,SexLabel,ScalesLabel,GAMM,ItemsLabel,IVtypeLabel,sep=""))

if(dir.exists(twd) == FALSE) { #create a directory specific to this model structure, per each "Mod", first see if it exists already
  dir.create(twd) #create the directory indexed by Mod
}

###########################################
### 2.4 set working directory #############
###########################################

setwd(twd) #send all output here,
print(list.files())


###########################################
### 2.4 set working directory #############
###########################################

print(AnlsVers);print(dim(data))
print(getwd())

