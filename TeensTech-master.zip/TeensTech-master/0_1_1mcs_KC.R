##########################################################################################
# Specification Curve Analysis and Digital Technology Use
# R-Script 1.3 KMC FORK: Set the working directory
#
# File: 0_1_1mcs_KC.R
# Author: KMC
# Notes:
# Ini Date: July 7, 2019
# set the working directory
##########################################################################################

### 1.0 Set up environment
#moved. deferred to each script

#!!!# comment out one of these
rootwd<-"~/Dionysus/Twenge/OrbenXS/TeensTech/" #this is on local machines
#rootwd<-"~XXXX" #this todd's space. this needs to be absolute not relative, cuz it will become recursive otherwise

### 2.0 Set up the tailoring

### 2.1 Select the Model

### 2.3 set up the Mod specific environment
twd<-(paste(rootwd,"OrbenExt",AnlsVers,SexLabel,ScalesLabel,GAMM,ItemsLabel,IVtypeLabel,sep=""))
setwd(twd) #send all output here,
print(list.files())

print(AnlsVers);print(dim(data))
print(getwd())













###example multicore
# library(parallel)
# library(doParallel)
# library(foreach)
# print(parallel::detectCores()) # how many cores?
# options(mc.cores = (parallel::detectCores()-2)) #set up to use all the cores - 2
# system.time ({
#   bootstraps<-1000
# foreach (i = 1:bootstraps) %do% {
#   mean(sqrt(rnorm(1000)^6/rnorm(1000)^2))
# }
#
# })
#
#
#
# system.time({
# bootstraps<-1000
# for (i in 1:bootstraps){
#  mean(sqrt(rnorm(1000)^6/rnorm(1000)^2))
# }
# })