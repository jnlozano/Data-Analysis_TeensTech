##########################################################################################
# Specification Curve Analysis and Digital Technology Use
# R-Script 0.2: Run across all the evalautions structurs
#
# File: 0_2_mcs_KC.R
# Author: KMC
# Notes: RUN the suite of models from this code. Update teh 0_3_mcs_PARAMETERS.R CODE.
# Ini Date: Aug 29, 2019
# Questions:
# History: 1.4 Adds option to limit the control variables
# Current Version: 1.4.1
##########################################################################################


setwd("~/Dionysus/Twenge/OrbenXS/TeensTech/") #this is on local machines
#rootwd<-"~XXXX" #this todd's space. this needs to be absolute not relative, cuz it will become recursive otherwise

### Rebuild: Original Model of Orben 2019
setwd("~/Dionysus/Twenge/OrbenXS/TeensTech/") #this is on local machines
rm(list = ls(all = TRUE)) #clear memory
Mod<-3
GAMM<-0 ; # use original Orben Linear Model = 0, GAMM = 1, piecewise with set knot point = 3 (confirm)
Scales<-1# 1use the DV scales
Items<-0 #Drop item exploration (the random permutations of item combos)
EmoItemOnly<-1; #Drop SDQ irrelevant q's
knot_location<-5 #gives the knot location for piecewise regresion Mod 3
LimitedControls<- 1 # limits the control variable to just the demographcs
NoSDQHeadAche<-0
SelfHarm<-1 #1 includes self-harm
IVtype <- 0 #what should the IVs be, zero is social media
dropSDQ<-0
PrintGraphs<-0 #set to one will cause graphs to dump in FigsDump
Scripted<-1
Sex<-0
RunNum<-1
source("1_3_prep_mcsKC.R")

#
# Mod<-1; # model 3 is social media only
# Sex<-1
# RunNum<-1
# Scripted <- 1 #run source from this, skipping out paramaterization/init steps in sourced code
# source("1_3_prep_mcsKC.R")
#  #Original Model of Orben 2019 with DVs limited: Confirmation Step
# setwd("~/Dionysus/Twenge/OrbenXS/TeensTech/") #this is on local machines
# rm(list = ls(all = TRUE)) #clear memory
#  GAMM<-0 ; # use original Orben Linear Model = 0, piecewise won't work correctly because the knot is based on social media, only
# Scales<-0 # use just the DV scales
#  Items<-1 #Use individual items and their combinations
#  EmoItemOnly<-0 #Drop SDQ irrelevant q's
#  LimitedControls<- 0
#  NoSDQHeadAche<-0
#  dropSDQ<-0
#  PrintGraphs<-0
#  IVtype <- 0 #what should the IVs be, zero is social media, 3 is internent
#
#
#  Mod<-1;Sex<-"NA"
#  RunNum<-1
#  Scripted <- 1 #run source from this, skipping out paramaterization/init steps in sourced code
  source("1_3_prep_mcsKC.R")
# #
#
#
#
# # # Make graphs
# # setwd("~/Dionysus/Twenge/OrbenXS/TeensTech/") #this is on local machines
# # rm(list = ls(all = TRUE)) #clear memory
# # GAMM<-0 ; # use original Orben Linear Model = 0, piecewise won't work correctly because the knot is based on social media, only
# # Scales<-1 # use just the DV scales
# # Items<-0 #Drop item exploration
# # EmoItemOnly<-1; #Drop SDQ irrelevant q's
# #
# # PrintGraphs<-1
# #
# # Mod<-3;
# # Sex<-0
# # RunNum<-1
# # Scripted <- 1 #run source from this, skipping out paramaterization/init steps in sourced code
# # source("1_3_prep_mcsKC.R")
#
#
# PrintGraphs<-0
#
# ########################## Step 1 ##############################
# # Original Model of Orben 2019 with DVs limited and social media exposure only: Step 1
# setwd("~/Dionysus/Twenge/OrbenXS/TeensTech/") #this is on local machines
# rm(list = ls(all = TRUE)) #clear memory
# GAMM<-0 ; # use original Orben Linear Model = 0, piecewise not setup for combined sex?
# Scales<-1 # use just the DV scales
# Items<-0 #Drop item exploration
# EmoItemOnly<-1; #Drop SDQ irrelevant q's
# IVtype <- 4 #what should the IVs be, zero is social media
#
#
# Mod<-5; # MUST BE ON THE ADJUSTED SCALE!!!! -2.05= 2, -0.1227 is 5; model 3 is social media only, 5 convert back to 3 after getting the right label
# Sex<-"NA"
# RunNum<-1
# Scripted <- 1 #run source from this, skipping out paramaterization/init steps in sourced code
# source("1_3_prep_mcsKC.R")
#
#
# ########################## Step 2 ##############################
# # Girsl: Original Model of Orben 2019 with DVs limited and social media exposure only: Step 2
# setwd("~/Dionysus/Twenge/OrbenXS/TeensTech/") #this is on local machines
# rm(list = ls(all = TRUE)) #clear memory
# GAMM<-0 ; # use original Orben Linear Model = 0, piecewise with set knot point = 3
# Scales<-1 # use just the DV scales
# Items<-0 #Drop item exploration
# EmoItemOnly<-1; #Drop SDQ irrelevant q's
# knot_location<-5 #gives the knot location for piecewise regresion Mod 3
# NoSDQHeadAche<-0
# SelfHarm<-0
# LimitedControls<- 1 # limits the control variable to just the demographcs
# IVtype <- 0 #what should the IVs be, zero is social media, 3 is internent
# dropSDQ<-0
#
# PrintGraphs<-0 #one dumps graphs in FigsDump
#
# Mod<-3; # model 3 is social media only
# Sex<-0
# RunNum<-1
# Scripted <- 1 #run source from this, skipping out paramaterization/init steps in sourced code
# source("1_3_prep_mcsKC.R")
#
# #### Boys only: Original Model of Orben 2019 with DVs limited and social media exposure only: Step 2
# setwd("~/Dionysus/Twenge/OrbenXS/TeensTech/") #this is on local machines
# rm(list = ls(all = TRUE)) #clear memory
# GAMM<-0 ; # use original Orben Linear Model = 0, piecewise with set knot point = 3
# Scales<-1 # use just the DV scales
# Items<-1 #Drop item exploration
# EmoItemOnly<-1; #Drop SDQ irrelevant q's
# knot_location<-5 #gives the knot location for piecewise regresion Mod 3
# NoSDQHeadAche<-0
# SelfHarm<-0
# LimitedControls<- 0 # limits the control variable to just the demographcs
# IVtype <-4 #what should the IVs be, zero is social media
# dropSDQ<-0
#
# Mod<-3; # model 3 is social media only
# Sex<-1
# RunNum<-1
# Scripted <- 1 #run source from this, skipping out paramaterization/init steps in sourced code
# source("1_3_prep_mcsKC.R")
#
#
#
# ########################## Step 2 ##############################
# # Girsl: Original Model of Orben 2019 with DVs limited and social media exposure only: Step 2
# setwd("~/Dionysus/Twenge/OrbenXS/TeensTech/") #this is on local machines
# rm(list = ls(all = TRUE)) #clear memory
# GAMM<-0 ; # use original Orben Linear Model = 0, piecewise with set knot point = 3
# Scales<-1 # use just the DV scales
# Items<-0 #Drop item exploration
# EmoItemOnly<-1; #Drop SDQ irrelevant q's
# knot_location<-5 #gives the knot location for piecewise regresion Mod 3
# NoSDQHeadAche<-0
# SelfHarm<-0
# LimitedControls<- 0 # limits the control variable to just the demographcs
# IVtype <- 4 #what should the IVs be, zero is social media, 3 is internent
# dropSDQ<-0
#
# PrintGraphs<-1 #one dumps graphs in FigsDump
#
# Mod<-3; # model 3 is social media only
# Sex<-0
# RunNum<-1
# Scripted <- 1 #run source from this, skipping out paramaterization/init steps in sourced code
# source("1_3_prep_mcsKC.R")
#
# #### Boys only: Original Model of Orben 2019 with DVs limited and social media exposure only: Step 2
# setwd("~/Dionysus/Twenge/OrbenXS/TeensTech/") #this is on local machines
# rm(list = ls(all = TRUE)) #clear memory
# GAMM<-0 ; # use original Orben Linear Model = 0, piecewise with set knot point = 3
# Scales<-1 # use just the DV scales
# Items<-0 #Drop item exploration
# EmoItemOnly<-1; #Drop SDQ irrelevant q's
# knot_location<-5 #gives the knot location for piecewise regresion Mod 3
# NoSDQHeadAche<-0
# SelfHarm<-0
# LimitedControls<- 0 # limits the control variable to just the demographcs
# IVtype <-4 #what should the IVs be, zero is social media
# dropSDQ<-0
#
# Mod<-3; # model 3 is social media only
# Sex<-1
# RunNum<-1
# Scripted <- 1 #run source from this, skipping out paramaterization/init steps in sourced code
# source("1_3_prep_mcsKC.R")
#
#
#
#
#
#
# ########################## Step 3: ##############################
# # Girls only: Original Model of Orben 2019 with DVs limited and social media exposure only and no headach and w/self-harm: Step 3
# setwd("~/Dionysus/Twenge/OrbenXS/TeensTech/") #this is on local machines
# rm(list = ls(all = TRUE)) #clear memory
# GAMM<-0 ; # use original Orben Linear Model = 0, GAMM = 1, piecewise with set knot point = 3 (confirm)
# Scales<-1 # use the DV scales
# Items<-0 #Drop item exploration (the random permutations of item combos)
# EmoItemOnly<-1; #Drop SDQ irrelevant q's
# knot_location<-5 #gives the knot location for piecewise regresion Mod 3
# LimitedControls<- 0 # limits the control variable to just the demographcs
# NoSDQHeadAche<-1
# SelfHarm<-1
# IVtype <- 4 #what should the IVs be, zero is social media
# dropSDQ<-0
#
# PrintGraphs<-0 #set to one will cause graphs to dump in FigsDump
#
# Mod<-3; # model 3 is social media only
# Sex<-0
# RunNum<-1
# Scripted <- 1 #run source from this, skipping out paramaterization/init steps in sourced code
# source("1_3_prep_mcsKC.R")
#
# ### Boys only: Original Model of Orben 2019 with DVs limited and social media exposure only: step 3
# setwd("~/Dionysus/Twenge/OrbenXS/TeensTech/") #this is on local machines
# rm(list = ls(all = TRUE)) #clear memory
# GAMM<-0 ; # use original Orben Linear Model = 0, GAMM = 1, piecewise with set knot point = 3 (confirm)
# Scales<-1 # use the DV scales
# Items<-0 #Drop item exploration (the random permutations of item combos)
# EmoItemOnly<-1; #Drop SDQ irrelevant q's
# knot_location<-5 #gives the knot location for piecewise regresion Mod 3
# LimitedControls<- 0 # limits the control variable to just the demographcs
# NoSDQHeadAche<-0
# SelfHarm<-1
# IVtype <- 4 #what should the IVs be, zero is social media
# dropSDQ<-0
# PrintGraphs<-0 #set to one will cause graphs to dump in FigsDump
#
# Mod<-3; # model 3 is social media only
# Sex<-1
# RunNum<-1
# Scripted <- 1 #run source from this, skipping out paramaterization/init steps in sourced code
# source("1_3_prep_mcsKC.R")
#
# #### TWENGE OCtober 10 extension of IVs
#
# ########################## combined output ##############################
# # loop sexes: Original Model of Orben 2019 with DVs limited and social media exposure only: Step 2 base
# library(gdata) #conven function to retain the loop macros
#
#
#
# #Sys.sleep(4*60*60)
# for(drp.sdq in 0:1){ #loop over if they sdq should be included
#   for(lim in 0:1) { #loop over limited controls
#     for (s in 0:1){ #loop over sex
#       for (ivtype in c(1,2,4,0) ){ #loop over the IV sets
#         for (si in 0:1){ #loop over scales or items investigation
#           print(si);print(ivtype);print(s)
#
#           setwd("~/Dionysus/Twenge/OrbenXS/TeensTech/") #this is on local machines
#           keep(c(s,ivtype,si), sure=TRUE) #rm(list = ls(all = TRUE)) #clear memory
#           GAMM<-0 ; # use original Orben Linear Model = 0, piecewise with set knot point = 3
#           Scales<-si # use just the DV scales if 1
#           if (si==0){
#             Items<-1 #keep item exploration
#           } else {
#             Items<-0 #Drop item exploration
#           }
#
#           EmoItemOnly<-1; #Drop SDQ irrelevant q's
#           knot_location<-5 #gives the knot location for piecewise regresion Mod 3
#           NoSDQHeadAche<-0
#           SelfHarm<-0
#           LimitedControls<- lim # limits the control variable to just the demographcs
#           IVtype <- ivtype #what should the IVs be, zero is social media, 3 is internent
#           dropSDQ<-drp.sdq
#
#           PrintGraphs<-0 #one dumps graphs in FigsDump
#
#           Mod<-3; # model 3 is social media only
#           Sex<-s
#           RunNum<-1
#           Scripted <- 1 #run source from this, skipping out paramaterization/init steps in sourced code
#           source("1_3_prep_mcsKC.R")
#
#           print(si);print(ivtype);print(s)
#         }
#       }
#     }
#   }
# }
#
#
#
#
#
#
#
#
#
#
#
#
#
# #### Boys only: Original Model of Orben 2019 with DVs limited and social media exposure only: Step 2
# setwd("~/Dionysus/Twenge/OrbenXS/TeensTech/") #this is on local machines
# rm(list = ls(all = TRUE)) #clear memory
# GAMM<-0 ; # use original Orben Linear Model = 0, piecewise with set knot point = 3
# Scales<-1 # use just the DV scales
# Items<-1 #Drop item exploration
# EmoItemOnly<-1; #Drop SDQ irrelevant q's
# knot_location<-5 #gives the knot location for piecewise regresion Mod 3
# NoSDQHeadAche<-0
# SelfHarm<-0
# LimitedControls<- 0 # limits the control variable to just the demographcs
# IVtype <-4 #what should the IVs be, zero is social media
#
# Mod<-3; # model 3 is social media only
# Sex<-1
# RunNum<-1
# Scripted <- 1 #run source from this, skipping out paramaterization/init steps in sourced code
# source("1_3_prep_mcsKC.R")
#
